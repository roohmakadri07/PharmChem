from django.http import HttpResponse, JsonResponse

# Create your views here.

import base64
import argparse
import cv2
import os

import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
tf.compat.v1.disable_eager_execution()
tf.reset_default_graph()

from ocr.DataLoader import Batch, DataLoader, FilePaths
from .SamplePreprocessor import preprocessor, wer
from ocr.Model import DecoderType, Model
from ocr.SpellChecker import correct_sentence


def index(request):
	data = request.GET["name"]
	return HttpResponse("hello "+data)

def decodeImg():
	#image = request.POST['image']

	with open('/Users/apple/Desktop/base64.txt', 'r') as file:
		data = file.read()
		
	# base64_text = open(image, "r")
	# img_data = base64_text.read()

	img_code = base64.b64decode(data)
	file.close()

	cntr=1

	file_name = '/Users/apple/Desktop/pharmchemOCR/ocr/incoming_imgs/' + str(cntr) + '.jpg'
	cntr+=1
	with open(file_name,'wb') as f:
		f.write(img_code)

	return file_name

def splitImg(file_name):
	img = cv2.imread(file_name)
	gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	print("1")

	th, threshed = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV|cv2.THRESH_OTSU)
	hist = cv2.reduce(threshed,1, cv2.REDUCE_AVG).reshape(-1)
	th = 2
	H,W = img.shape[:2]
	uppers = [y for y in range(H-1) if hist[y]<=th and hist[y+1]>th]
	lowers = [y for y in range(H-1) if hist[y]>th and hist[y+1]<=th]

	

	dir = '/Users/apple/Desktop/pharmchemOCR/ocr/result_split'
	for f in os.listdir(dir):
		print("2")
		os.remove(os.path.join(dir, f))

	img_num = 1

	for i in range(len(uppers)):
		cv2.imwrite('/Users/apple/Desktop/pharmchemOCR/ocr/result_split/' + str(img_num) + '.jpg', img[uppers[i]:lowers[i],:])
		img_num += 1  

def main(request):
	img = decodeImg()
	splitImg(img)

	return HttpResponse('split done')
