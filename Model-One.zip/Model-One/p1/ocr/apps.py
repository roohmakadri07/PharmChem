from django.apps import AppConfig


class OcrConfig(AppConfig):
    name = 'ocr'
