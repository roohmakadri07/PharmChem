<?php
include 'innertop.php';
$id = $_GET['id'];

?>



<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-5 col-sm-12">
                <h2>Stater Page
                    <small>Welcome to Pharm-Chem</small>
                </h2>
            </div>
            <div class="col-lg-5 col-md-7 col-sm-12">
                <button class="btn btn-white btn-icon btn-round d-none d-md-inline-block float-right m-l-10" type="button">
                    <i class="zmdi zmdi-plus"></i>
                </button>
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="index.html"><i class="zmdi zmdi-home"></i> Oreo</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Sample Pages</a></li>
                    <li class="breadcrumb-item active">Stater Page</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row clearfix">
            <div class="col-md-12">
                <div class="card patients-list">
                    <div class="header">
                        <h2><strong>Patient </strong>Medical Details</h2>
                        <ul class="header-dropdown">
                            <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                    <i class="zmdi zmdi-more"></i> </a>

                            </li>
                            <li class="remove">
                                <a role="button" class="boxs-close"><i class="zmdi zmdi-close"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="body">
                        <form action="code.php" method="POST">
                            <?php
                            // echo $id;
                            $query = "SELECT p_id FROM patient WHERE u_id='$id'";
                            $result = mysqli_query($con, $query);
                            ?>


                            <div class="tab-content m-t-10">
                                <div class="tab-pane table-responsive active" id="All">
                                    <table class="table m-b-0 table-hover">
                                        <thead>
                                            <tr>
                                                <th>Prescription ID</th>
                                                <th>Symptoms Name</th>
                                                
                                                <th>Check Box</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            while ($r = mysqli_fetch_array($result)) {
                                                $pid = $r['p_id'];
                                                $query2 = "SELECT s_id from prescription_symptoms where p_id=$pid";
                                                $result2 = mysqli_query($con, $query2);
                                                while ($r2 = mysqli_fetch_array($result2)) {
                                                    $sid = $r2['s_id'];
                                                    $query3 = "SELECT s_name from symptoms where s_id=$sid";
                                                    $result3 = mysqli_query($con, $query3);
                                                    while ($r3 = mysqli_fetch_array($result3))
                                                    {
                                            ?>

                                                    <tr>
                                                        <td><span class="list-name"><?= $r['p_id']?></span></td>
                                                        <td><?php echo $r3['s_name']; ?></td>
                                                        
                                                        <td>
                                                            <input id="checkbox1" name="checkList[]" type="checkbox" value="<?= $r['p_id']?>">
                                                            <label for="checkbox1">Check</label>
                                                        </td>
                                                    </tr>
                                            <?php
                                                    }
                                                }
                                            }

                                            ?>


                                        </tbody>
                                    </table>
                                </div>
                                
                                <button type="submit" name="view_multiple" class="btn btn-primary btn-round">Search</button>


                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>



<?php include 'innerbottom.php'; ?>