<?php
include "db.php";


    $allid  = $_POST['checkList'];
    // $extract_id = implode(',',$allid);
    // echo $extract_id;

    if(count(array_unique($allid)) > 1)
    {
        echo "<script>alert('No Record Found');location.href='home.php'</script>";
    }
    elseif(count(array_unique($allid)) == 1)
    {

        $id1 = $allid[0];
        echo "<script>location.href = 'symptom_medicine.php?id=$id1'</script>";
    }

    // if(count($allid))
    // $allvaluesaresame = (count(array_unique($allid))==1);
    // echo $allvaluesaresame; 

?>