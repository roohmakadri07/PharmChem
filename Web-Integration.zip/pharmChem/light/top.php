<!doctype html>
<html class="no-js " lang="en">

<!-- Mirrored from thememakker.com/templates/oreo/hospital/html/light/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Aug 2022 05:05:52 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="description" content="Responsive Bootstrap 4 and web Application ui kit.">
    <title>:: PharmChem :: Home</title>
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/plugins/jvectormap/jquery-jvectormap-2.0.3.min.css" />
    <link rel="stylesheet" href="../assets/plugins/morrisjs/morris.min.css" />

    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/color_skins.css">
</head>

<body class="theme-cyan">

    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30"><img class="zmdi-hc-spin"
                    src="https://thememakker.com/templates/oreo/hospital/html/assets/images/logo.svg" width="48"
                    height="48" alt="Oreo"></div>
            <p>Please wait...</p>
        </div>
    </div>

    <div class="overlay"></div>

    <nav class="navbar p-l-5 p-r-5">
        <ul class="nav navbar-nav navbar-left">
            <li>
                <div class="navbar-header">
                    <a href="javascript:void(0);" class="bars"></a>
                    <a class="navbar-brand" href="index.html"><img
                            src="https://thememakker.com/templates/oreo/hospital/html/assets/images/logo.svg" width="30"
                            alt="Oreo"><span class="m-l-10">Pharm-Chem</span></a>
                </div>
            </li>
            <li><a href="javascript:void(0);" class="ls-toggle-btn" data-close="true"><i class="zmdi zmdi-swap"></i></a>
            </li>
            <li class="d-none d-lg-inline-block"><a href="events.html" title="Events"><i
                        class="zmdi zmdi-calendar"></i></a></li>
            <li class="d-none d-lg-inline-block"><a href="mail-inbox.html" title="Inbox"><i
                        class="zmdi zmdi-email"></i></a></li>
            <li><a href="contact.html" title="Contact List"><i class="zmdi zmdi-account-box-phone"></i></a></li>
            <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown"
                    role="button"><i class="zmdi zmdi-notifications"></i>
                    <div class="notify"><span class="heartbit"></span><span class="point"></span></div>
                </a>
                <ul class="dropdown-menu pullDown">
                    <li class="body">
                        <ul class="menu list-unstyled">
                            <li>
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object" src="../assets/images/xs/avatar2.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Sophia <span class="time">30min ago</span></span>
                                            <span class="message">There are many variations of passages</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object" src="../assets/images/xs/avatar3.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Sophia <span class="time">31min ago</span></span>
                                            <span class="message">There are many variations of passages of Lorem
                                                Ipsum</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object" src="../assets/images/xs/avatar4.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Isabella <span class="time">35min ago</span></span>
                                            <span class="message">There are many variations of passages</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object" src="../assets/images/xs/avatar5.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Alexander <span class="time">35min ago</span></span>
                                            <span class="message">Contrary to popular belief, Lorem Ipsum random</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object" src="../assets/images/xs/avatar6.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Grayson <span class="time">1hr ago</span></span>
                                            <span class="message">There are many variations of passages</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="footer"> <a href="javascript:void(0);">View All</a> </li>
                </ul>
            </li>
            <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown"
                    role="button"><i class="zmdi zmdi-flag"></i>
                    <div class="notify">
                        <span class="heartbit"></span>
                        <span class="point"></span>
                    </div>
                </a>
                <ul class="dropdown-menu pullDown">
                    <li class="header">Project</li>
                    <li class="body">
                        <ul class="menu tasks list-unstyled">
                            <li>
                                <a href="javascript:void(0);">
                                    <div class="progress-container progress-primary">
                                        <span class="progress-badge">Neurology</span>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="86"
                                                aria-valuemin="0" aria-valuemax="100" style="width: 86%;">
                                                <span class="progress-value">86%</span>
                                            </div>
                                        </div>
                                        <ul class="list-unstyled team-info">
                                            <li class="m-r-15"><small class="text-muted">Team</small></li>
                                            <li>
                                                <img src="../assets/images/xs/avatar2.jpg" alt="Avatar">
                                            </li>
                                            <li>
                                                <img src="../assets/images/xs/avatar3.jpg" alt="Avatar">
                                            </li>
                                            <li>
                                                <img src="../assets/images/xs/avatar4.jpg" alt="Avatar">
                                            </li>
                                        </ul>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0);">
                                    <div class="progress-container progress-info">
                                        <span class="progress-badge">Gynecology</span>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="45"
                                                aria-valuemin="0" aria-valuemax="100" style="width: 45%;">
                                                <span class="progress-value">45%</span>
                                            </div>
                                        </div>
                                        <ul class="list-unstyled team-info">
                                            <li class="m-r-15"><small class="text-muted">Team</small></li>
                                            <li>
                                                <img src="../assets/images/xs/avatar10.jpg" alt="Avatar">
                                            </li>
                                            <li>
                                                <img src="../assets/images/xs/avatar9.jpg" alt="Avatar">
                                            </li>
                                            <li>
                                                <img src="../assets/images/xs/avatar8.jpg" alt="Avatar">
                                            </li>
                                            <li>
                                                <img src="../assets/images/xs/avatar7.jpg" alt="Avatar">
                                            </li>
                                            <li>
                                                <img src="../assets/images/xs/avatar6.jpg" alt="Avatar">
                                            </li>
                                        </ul>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0);">
                                    <div class="progress-container progress-warning">
                                        <span class="progress-badge">Cardio Monitoring</span>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="29"
                                                aria-valuemin="0" aria-valuemax="100" style="width: 29%;">
                                                <span class="progress-value">29%</span>
                                            </div>
                                        </div>
                                        <ul class="list-unstyled team-info">
                                            <li class="m-r-15"><small class="text-muted">Team</small></li>
                                            <li>
                                                <img src="../assets/images/xs/avatar5.jpg" alt="Avatar">
                                            </li>
                                            <li>
                                                <img src="../assets/images/xs/avatar2.jpg" alt="Avatar">
                                            </li>
                                            <li>
                                                <img src="../assets/images/xs/avatar7.jpg" alt="Avatar">
                                            </li>
                                        </ul>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="footer"><a href="javascript:void(0);">View All</a></li>
                </ul>
            </li>
            <li class="d-none d-md-inline-block">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search...">
                    <span class="input-group-addon">
                        <i class="zmdi zmdi-search"></i>
                    </span>
                </div>
            </li>
            <li class="float-right">
                <a href="sign-in.html" class="mega-menu" data-close="true"><i class="zmdi zmdi-power"></i></a>
                <a href="javascript:void(0);" class="js-right-sidebar" data-close="true"><i
                        class="zmdi zmdi-settings zmdi-hc-spin"></i></a>
            </li>
        </ul>
    </nav>

    <aside id="leftsidebar" class="sidebar">
        <ul class="nav nav-tabs">
            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#dashboard"><i
                        class="zmdi zmdi-home m-r-5"></i>Oreo</a></li>
            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#user">Doctor</a></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane stretchRight active" id="dashboard">
                <div class="menu">
                    <ul class="list">
                        <li>
                            <div class="user-info">
                                <div class="image"><a href="profile.html"><img src="../assets/images/profile_av.jpg"
                                            alt="User"></a></div>
                                <div class="detail">
                                    <h4>Dr. Charlotte</h4>
                                    <small>Neurologist</small>
                                </div>
                            </div>
                        </li>
                        <li class="header">MAIN</li>
                        <li class="active open"><a href="index.html"><i
                                    class="zmdi zmdi-home"></i><span>Dashboard</span></a></li>
                        <li><a href="book-appointment.html"><i
                                    class="zmdi zmdi-calendar-check"></i><span>Appointment</span> </a></li>
                        <li><a href="javascript:void(0);" class="menu-toggle"><i
                                    class="zmdi zmdi-account-add"></i><span>Doctors</span> </a>
                            <ul class="ml-menu">
                                <li><a href="doctors.html">All Doctors</a></li>
                                <li><a href="add-doctor.html">Add Doctor</a></li>
                                <li><a href="profile.html">Doctor Profile</a></li>
                                <li><a href="events.html">Doctor Schedule</a></li>
                            </ul>
                        </li>
                        <li><a href="javascript:void(0);" class="menu-toggle"><i
                                    class="zmdi zmdi-account-o"></i><span>Patients</span> </a>
                            <ul class="ml-menu">
                                <li><a href="patients.html">All Patients</a></li>
                                <li><a href="add-patient.html">Add Patient</a></li>
                                <li><a href="patient-profile.html">Patient Profile</a></li>
                                <li><a href="patient-invoice.html">Invoice</a></li>
                            </ul>
                        </li>
                        <li><a href="javascript:void(0);" class="menu-toggle"><i
                                    class="zmdi zmdi-balance-wallet"></i><span>Payments</span> </a>
                            <ul class="ml-menu">
                                <li><a href="payments.html">Payments</a></li>
                                <li><a href="add-payments.html">Add Payment</a></li>
                                <li><a href="invoice.html">Invoice</a></li>
                            </ul>
                        </li>
                        <li><a href="javascript:void(0);" class="menu-toggle"><i
                                    class="zmdi zmdi-label-alt"></i><span>Departments</span> </a>
                            <ul class="ml-menu">
                                <li><a href="add-departments.html">Add</a></li>
                                <li><a href="all-Departments.html">All Departments</a></li>
                                <li><a href="javascript:void(0);">Cardiology</a></li>
                                <li><a href="javascript:void(0);">Pulmonology</a></li>
                                <li><a href="javascript:void(0);">Gynecology</a></li>
                                <li><a href="javascript:void(0);">Neurology</a></li>
                                <li><a href="javascript:void(0);">Urology</a></li>
                                <li><a href="javascript:void(0);">Gastrology</a></li>
                                <li><a href="javascript:void(0);">Pediatrician</a></li>
                                <li><a href="javascript:void(0);">Laboratory</a></li>
                            </ul>
                        </li>
                        <li> <a href="javascript:void(0);" class="menu-toggle"><i
                                    class="zmdi zmdi-lock"></i><span>Authentication</span> </a>
                            <ul class="ml-menu">
                                <li><a href="sign-in.html">Sign In</a> </li>
                                <li><a href="sign-up.html">Sign Up</a> </li>
                                <li><a href="forgot-password.html">Forgot Password</a> </li>
                                <li><a href="404.html">Page 404</a> </li>
                                <li><a href="500.html">Page 500</a> </li>
                                <li><a href="page-offline.html">Page Offline</a> </li>
                                <li><a href="locked.html">Locked Screen</a> </li>
                            </ul>
                        </li>
                        <li class="header">EXTRA COMPONENTS</li>
                        <li><a href="javascript:void(0);" class="menu-toggle"><i
                                    class="zmdi zmdi-blogger"></i><span>Blog</span></a>
                            <ul class="ml-menu">
                                <li><a href="blog-dashboard.html">Blog Dashboard</a></li>
                                <li><a href="blog-post.html">New Post</a></li>
                                <li><a href="blog-list.html">Blog List</a></li>
                                <li><a href="blog-grid.html">Blog Grid</a></li>
                                <li><a href="blog-details.html">Blog Single</a></li>
                            </ul>
                        </li>
                        <li><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-folder"></i><span>File
                                    Manager</span> </a>
                            <ul class="ml-menu">
                                <li><a href="file-dashboard.html">All File</a></li>
                                <li><a href="file-documents.html">Documents</a></li>
                                <li><a href="file-media.html">Media</a></li>
                                <li><a href="file-images.html">Images</a></li>
                            </ul>
                        </li>
                        <li> <a href="javascript:void(0);" class="menu-toggle"><i
                                    class="zmdi zmdi-apps"></i><span>App</span> </a>
                            <ul class="ml-menu">
                                <li><a href="mail-inbox.html">Inbox</a></li>
                                <li><a href="chat.html">Chat</a></li>
                                <li><a href="contact.html">Contact list</a></li>
                            </ul>
                        </li>
                        <li> <a href="javascript:void(0);" class="menu-toggle"><i
                                    class="zmdi zmdi-delicious"></i><span>Widgets</span> </a>
                            <ul class="ml-menu">
                                <li><a href="widgets-app.html">Apps Widgetse</a></li>
                                <li><a href="widgets-data.html">Data Widgetse</a></li>
                            </ul>
                        </li>
                        <li> <a href="javascript:void(0);" class="menu-toggle"><i
                                    class="zmdi zmdi-copy"></i><span>Sample Pages</span> </a>
                            <ul class="ml-menu">
                                <li><a href="blank.html">Blank Page</a> </li>
                                <li><a href="https://thememakker.com/templates/oreo/hospital/html/rtl/index.html">RTL
                                        Support</a></li>
                                <li><a href="image-gallery.html">Image Gallery</a> </li>
                                <li><a href="profile.html">Profile</a></li>
                                <li><a href="timeline.html">Timeline</a></li>
                                <li><a href="invoice.html">Invoices</a></li>
                                <li><a href="search-results.html">Search Results</a></li>
                            </ul>
                        </li>
                        <li> <a href="javascript:void(0);" class="menu-toggle"><i
                                    class="zmdi zmdi-swap-alt"></i><span>User Interface (UI)</span> </a>
                            <ul class="ml-menu">
                                <li><a href="ui_kit.html">UI KIT</a></li>
                                <li><a href="alerts.html">Alerts</a></li>
                                <li><a href="collapse.html">Collapse</a></li>
                                <li><a href="colors.html">Colors</a></li>
                                <li><a href="dialogs.html">Dialogs</a></li>
                                <li><a href="icons.html">Icons</a></li>
                                <li><a href="list-group.html">List Group</a></li>
                                <li><a href="media-object.html">Media Object</a></li>
                                <li><a href="modals.html">Modals</a></li>
                                <li><a href="notifications.html">Notifications</a></li>
                                <li><a href="progressbars.html">Progress Bars</a></li>
                                <li><a href="range-sliders.html">Range Sliders</a></li>
                                <li><a href="sortable-nestable.html">Sortable & Nestable</a></li>
                                <li><a href="tabs.html">Tabs</a></li>
                                <li><a href="waves.html">Waves</a></li>
                            </ul>
                        </li>
                        <li class="header">Extra</li>
                        <li>
                            <div class="progress-container progress-primary m-t-10">
                                <span class="progress-badge">Traffic this Month</span>
                                <div class="progress">
                                    <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="67"
                                        aria-valuemin="0" aria-valuemax="100" style="width: 67%;">
                                        <span class="progress-value">67%</span>
                                    </div>
                                </div>
                            </div>
                            <div class="progress-container progress-info">
                                <span class="progress-badge">Server Load</span>
                                <div class="progress">
                                    <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="86"
                                        aria-valuemin="0" aria-valuemax="100" style="width: 86%;">
                                        <span class="progress-value">86%</span>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="tab-pane stretchLeft" id="user">
                <div class="menu">
                    <ul class="list">
                        <li>
                            <div class="user-info m-b-20 p-b-15">
                                <div class="image"><a href="profile.html"><img src="../assets/images/profile_av.jpg"
                                            alt="User"></a></div>
                                <div class="detail">
                                    <h4>Dr. Charlotte</h4>
                                    <small>Neurologist</small>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <a title="facebook" href="#"><i class="zmdi zmdi-facebook"></i></a>
                                        <a title="twitter" href="#"><i class="zmdi zmdi-twitter"></i></a>
                                        <a title="instagram" href="#"><i class="zmdi zmdi-instagram"></i></a>
                                    </div>
                                    <div class="col-4 p-r-0">
                                        <h5 class="m-b-5">18</h5>
                                        <small>Exp</small>
                                    </div>
                                    <div class="col-4">
                                        <h5 class="m-b-5">125</h5>
                                        <small>Awards</small>
                                    </div>
                                    <div class="col-4 p-l-0">
                                        <h5 class="m-b-5">148</h5>
                                        <small>Clients</small>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <small class="text-muted">Location: </small>
                            <p>795 Folsom Ave, Suite 600 San Francisco, CADGE 94107</p>
                            <hr>
                            <small class="text-muted">Email address: </small>
                            <p><a href="https://thememakker.com/cdn-cgi/l/email-protection" class="__cf_email__"
                                    data-cfemail="692a01081b05061d1d0c290c11080419050c470a0604">[email&#160;protected]</a>
                            </p>
                            <hr>
                            <small class="text-muted">Phone: </small>
                            <p>+ 202-555-0191</p>
                            <hr>
                            <small class="text-muted">Website: </small>
                            <p>dr.charlotte.com/ </p>
                            <hr>
                            <ul class="list-unstyled">
                                <li>
                                    <div>Colorectal Surgery</div>
                                    <div class="progress m-b-20">
                                        <div class="progress-bar l-blue " role="progressbar" aria-valuenow="89"
                                            aria-valuemin="0" aria-valuemax="100" style="width: 89%"> <span
                                                class="sr-only">62% Complete</span> </div>
                                    </div>
                                </li>
                                <li>
                                    <div>Endocrinology</div>
                                    <div class="progress m-b-20">
                                        <div class="progress-bar l-green " role="progressbar" aria-valuenow="56"
                                            aria-valuemin="0" aria-valuemax="100" style="width: 56%"> <span
                                                class="sr-only">87% Complete</span> </div>
                                    </div>
                                </li>
                                <li>
                                    <div>Dermatology</div>
                                    <div class="progress m-b-20">
                                        <div class="progress-bar l-amber" role="progressbar" aria-valuenow="78"
                                            aria-valuemin="0" aria-valuemax="100" style="width: 78%"> <span
                                                class="sr-only">32% Complete</span> </div>
                                    </div>
                                </li>
                                <li>
                                    <div>Neurophysiology</div>
                                    <div class="progress m-b-20">
                                        <div class="progress-bar l-blush" role="progressbar" aria-valuenow="43"
                                            aria-valuemin="0" aria-valuemax="100" style="width: 43%"> <span
                                                class="sr-only">56% Complete</span> </div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </aside>

    <aside id="rightsidebar" class="right-sidebar">
        <ul class="nav nav-tabs">
            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#setting"><i
                        class="zmdi zmdi-settings zmdi-hc-spin"></i></a></li>
            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#chat"><i
                        class="zmdi zmdi-comments"></i></a></li>
            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#activity">Activity</a></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane slideRight active" id="setting">
                <div class="slim_scroll">
                    <div class="card">
                        <h6>General Settings</h6>
                        <ul class="setting-list list-unstyled">
                            <li>
                                <div class="checkbox">
                                    <input id="checkbox1" type="checkbox">
                                    <label for="checkbox1">Report Panel Usage</label>
                                </div>
                            </li>
                            <li>
                                <div class="checkbox">
                                    <input id="checkbox2" type="checkbox" checked="">
                                    <label for="checkbox2">Email Redirect</label>
                                </div>
                            </li>
                            <li>
                                <div class="checkbox">
                                    <input id="checkbox3" type="checkbox" checked="">
                                    <label for="checkbox3">Notifications</label>
                                </div>
                            </li>
                            <li>
                                <div class="checkbox">
                                    <input id="checkbox4" type="checkbox" checked="">
                                    <label for="checkbox4">Auto Updates</label>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="card">
                        <h6>Skins</h6>
                        <ul class="choose-skin list-unstyled">
                            <li data-theme="purple">
                                <div class="purple"></div>
                            </li>
                            <li data-theme="blue">
                                <div class="blue"></div>
                            </li>
                            <li data-theme="cyan" class="active">
                                <div class="cyan"></div>
                            </li>
                            <li data-theme="green">
                                <div class="green"></div>
                            </li>
                            <li data-theme="orange">
                                <div class="orange"></div>
                            </li>
                            <li data-theme="blush">
                                <div class="blush"></div>
                            </li>
                        </ul>
                    </div>
                    <div class="card">
                        <h6>Account Settings</h6>
                        <ul class="setting-list list-unstyled">
                            <li>
                                <div class="checkbox">
                                    <input id="checkbox5" type="checkbox" checked="">
                                    <label for="checkbox5">Offline</label>
                                </div>
                            </li>
                            <li>
                                <div class="checkbox">
                                    <input id="checkbox6" type="checkbox" checked="">
                                    <label for="checkbox6">Location Permission</label>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="card theme-light-dark">
                        <h6>Left Menu</h6>
                        <button class="t-light btn btn-default btn-simple btn-round btn-block">Light</button>
                        <button class="t-dark btn btn-default btn-round btn-block">Dark</button>
                        <button class="m_img_btn btn btn-primary btn-round btn-block">Sidebar Image</button>
                    </div>
                    <div class="card">
                        <h6>Information Summary</h6>
                        <div class="row m-b-20">
                            <div class="col-7">
                                <small class="displayblock">MEMORY USAGE</small>
                                <h5 class="m-b-0 h6">512</h5>
                            </div>
                            <div class="col-5">
                                <div class="sparkline" data-type="bar" data-width="97%" data-height="25px"
                                    data-bar-Width="5" data-bar-Spacing="3" data-bar-Color="#00ced1">8,7,9,5,6,4,6,8
                                </div>
                            </div>
                        </div>
                        <div class="row m-b-20">
                            <div class="col-7">
                                <small class="displayblock">CPU USAGE</small>
                                <h5 class="m-b-0 h6">90%</h5>
                            </div>
                            <div class="col-5">
                                <div class="sparkline" data-type="bar" data-width="97%" data-height="25px"
                                    data-bar-Width="5" data-bar-Spacing="3" data-bar-Color="#F15F79">6,5,8,2,6,4,6,4
                                </div>
                            </div>
                        </div>
                        <div class="row m-b-20">
                            <div class="col-7">
                                <small class="displayblock">DAILY TRAFFIC</small>
                                <h5 class="m-b-0 h6">25 142</h5>
                            </div>
                            <div class="col-5">
                                <div class="sparkline" data-type="bar" data-width="97%" data-height="25px"
                                    data-bar-Width="5" data-bar-Spacing="3" data-bar-Color="#78b83e">7,5,8,7,4,2,6,5
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-7">
                                <small class="displayblock">DISK USAGE</small>
                                <h5 class="m-b-0 h6">60.10%</h5>
                            </div>
                            <div class="col-5">
                                <div class="sparkline" data-type="bar" data-width="97%" data-height="25px"
                                    data-bar-Width="5" data-bar-Spacing="3" data-bar-Color="#457fca">7,5,2,5,6,7,6,4
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane right_chat stretchLeft" id="chat">
                <div class="slim_scroll">
                    <div class="card">
                        <div class="search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-addon">
                                    <i class="zmdi zmdi-search"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <h6>Recent</h6>
                        <ul class="list-unstyled">
                            <li class="online">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar4.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Sophia</span>
                                            <span class="message">There are many variations of passages of Lorem Ipsum
                                                available</span>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="online">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar5.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Grayson</span>
                                            <span class="message">All the Lorem Ipsum generators on the</span>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="offline">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar2.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Isabella</span>
                                            <span class="message">Contrary to popular belief, Lorem Ipsum</span>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="me">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar1.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">John</span>
                                            <span class="message">It is a long established fact that a reader</span>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="online">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar3.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Alexander</span>
                                            <span class="message">Richard McClintock, a Latin professor</span>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="card">
                        <h6>Contacts</h6>
                        <ul class="list-unstyled">
                            <li class="offline inlineblock">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar10.jpg" alt="">
                                        <div class="media-body">
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="offline inlineblock">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar6.jpg" alt="">
                                        <div class="media-body">
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="offline inlineblock">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar7.jpg" alt="">
                                        <div class="media-body">
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="offline inlineblock">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar8.jpg" alt="">
                                        <div class="media-body">
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="offline inlineblock">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar9.jpg" alt="">
                                        <div class="media-body">
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="online inlineblock">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar5.jpg" alt="">
                                        <div class="media-body">
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="offline inlineblock">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar4.jpg" alt="">
                                        <div class="media-body">
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="offline inlineblock">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar3.jpg" alt="">
                                        <div class="media-body">
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="online inlineblock">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar2.jpg" alt="">
                                        <div class="media-body">
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="offline inlineblock">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="../assets/images/xs/avatar1.jpg" alt="">
                                        <div class="media-body">
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="tab-pane slideLeft" id="activity">
                <div class="slim_scroll">
                    <div class="card user_activity">
                        <h6>Recent Activity</h6>
                        <div class="streamline b-accent">
                            <div class="sl-item">
                                <img class="user rounded-circle" src="../assets/images/xs/avatar4.jpg" alt="">
                                <div class="sl-content">
                                    <h5 class="m-b-0">Admin Birthday</h5>
                                    <small>Jan 21 <a href="javascript:void(0);" class="text-info">Sophia</a>.</small>
                                </div>
                            </div>
                            <div class="sl-item">
                                <img class="user rounded-circle" src="../assets/images/xs/avatar5.jpg" alt="">
                                <div class="sl-content">
                                    <h5 class="m-b-0">Add New Contact</h5>
                                    <small>30min ago <a href="javascript:void(0);">Alexander</a>.</small>
                                    <small><strong>P:</strong> +264-625-2323</small>
                                    <small><strong>E:</strong> <a
                                            href="https://thememakker.com/cdn-cgi/l/email-protection"
                                            class="__cf_email__"
                                            data-cfemail="771a16050e161a161a1e051e37101a161e1b5914181a">[email&#160;protected]</a></small>
                                </div>
                            </div>
                            <div class="sl-item">
                                <img class="user rounded-circle" src="../assets/images/xs/avatar6.jpg" alt="">
                                <div class="sl-content">
                                    <h5 class="m-b-0">Code Change</h5>
                                    <small>Today <a href="javascript:void(0);">Grayson</a>.</small>
                                    <small>The standard chunk of Lorem Ipsum used since the 1500s is reproduced</small>
                                </div>
                            </div>
                            <div class="sl-item">
                                <img class="user rounded-circle" src="../assets/images/xs/avatar7.jpg" alt="">
                                <div class="sl-content">
                                    <h5 class="m-b-0">New Email</h5>
                                    <small>45min ago <a href="javascript:void(0);" class="text-info">Fidel
                                            Tonn</a>.</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <h6>Recent Attachments</h6>
                        <ul class="list-unstyled activity">
                            <li>
                                <a href="javascript:void(0)">
                                    <i class="zmdi zmdi-collection-pdf l-blush"></i>
                                    <div class="info">
                                        <h4>info_258.pdf</h4>
                                        <small>2MB</small>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)">
                                    <i class="zmdi zmdi-collection-text l-amber"></i>
                                    <div class="info">
                                        <h4>newdoc_214.doc</h4>
                                        <small>900KB</small>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)">
                                    <i class="zmdi zmdi-image l-parpl"></i>
                                    <div class="info">
                                        <h4>MG_4145.jpg</h4>
                                        <small>5.6MB</small>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)">
                                    <i class="zmdi zmdi-image l-parpl"></i>
                                    <div class="info">
                                        <h4>MG_4100.jpg</h4>
                                        <small>5MB</small>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)">
                                    <i class="zmdi zmdi-collection-text l-amber"></i>
                                    <div class="info">
                                        <h4>Reports_end.doc</h4>
                                        <small>780KB</small>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)">
                                    <i class="zmdi zmdi-videocam l-turquoise"></i>
                                    <div class="info">
                                        <h4>movie2018.MKV</h4>
                                        <small>750MB</small>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </aside>

    <div class="chat-launcher"></div>
    <div class="chat-wrapper">
        <div class="card">
            <div class="header">
                <ul class="list-unstyled team-info margin-0">
                    <li class="m-r-15">
                        <h2>Dr. Team</h2>
                    </li>
                    <li>
                        <img src="../assets/images/xs/avatar2.jpg" alt="Avatar">
                    </li>
                    <li>
                        <img src="../assets/images/xs/avatar3.jpg" alt="Avatar">
                    </li>
                    <li>
                        <img src="../assets/images/xs/avatar4.jpg" alt="Avatar">
                    </li>
                    <li>
                        <img src="../assets/images/xs/avatar6.jpg" alt="Avatar">
                    </li>
                    <li>
                        <a href="javascript:void(0);" title="Add Member"><i class="zmdi zmdi-plus-circle"></i></a>
                    </li>
                </ul>
            </div>
            <div class="body">
                <div class="chat-widget">
                    <ul class="chat-scroll-list clearfix">
                        <li class="left float-left">
                            <img src="../assets/images/xs/avatar3.jpg" class="rounded-circle" alt="">
                            <div class="chat-info">
                                <a class="name" href="#">Alexander</a>
                                <span class="datetime">6:12</span>
                                <span class="message">Hello, John </span>
                            </div>
                        </li>
                        <li class="right">
                            <div class="chat-info"><span class="datetime">6:15</span> <span class="message">Hi,
                                    Alexander<br> How are you!</span> </div>
                        </li>
                        <li class="right">
                            <div class="chat-info"><span class="datetime">6:16</span> <span class="message">There are
                                    many variations of passages of Lorem Ipsum available</span> </div>
                        </li>
                        <li class="left float-left"> <img src="../assets/images/xs/avatar2.jpg" class="rounded-circle"
                                alt="">
                            <div class="chat-info"> <a class="name" href="#">Elizabeth</a> <span
                                    class="datetime">6:25</span> <span class="message">Hi, Alexander,<br> John <br> What
                                    are you doing?</span> </div>
                        </li>
                        <li class="left float-left"> <img src="../assets/images/xs/avatar1.jpg" class="rounded-circle"
                                alt="">
                            <div class="chat-info"> <a class="name" href="#">Michael</a> <span
                                    class="datetime">6:28</span> <span class="message">I would love to join the
                                    team.</span> </div>
                        </li>
                        <li class="right">
                            <div class="chat-info"><span class="datetime">7:02</span> <span class="message">Hello,
                                    <br>Michael</span> </div>
                        </li>
                    </ul>
                </div>
                <div class="input-group p-t-15">
                    <input type="text" class="form-control" placeholder="Enter text here...">
                    <span class="input-group-addon">
                        <i class="zmdi zmdi-mail-send"></i>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <section class="content home">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-12">
                    <h2>Dashboard
                        <small>Welcome to PharmChem</small>
                    </h2>
                </div>
                <div class="col-lg-7 col-md-7 col-sm-12 text-right">
                    <div class="inlineblock text-center m-r-15 m-l-15 d-none d-lg-inline-block">
                        <div class="sparkline" data-type="bar" data-width="97%" data-height="25px" data-bar-Width="2"
                            data-bar-Spacing="5" data-bar-Color="#fff">3,2,6,5,9,8,7,9,5,1,3,5,7,4,6</div>
                        <small class="col-white">Visitors</small>
                    </div>
                    <div class="inlineblock text-center m-r-15 m-l-15 d-none d-lg-inline-block">
                        <div class="sparkline" data-type="bar" data-width="97%" data-height="25px" data-bar-Width="2"
                            data-bar-Spacing="5" data-bar-Color="#fff">1,3,5,7,4,6,3,2,6,5,9,8,7,9,5</div>
                        <small class="col-white">Operations</small>
                    </div>
                    
                    <ul class="breadcrumb float-md-right">
                        <li class="breadcrumb-item"><a href="index.html"><i class="zmdi zmdi-home"></i> Oreo</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row clearfix">
                <div class="col-lg-4 col-md-6">
                    <div class="card">
                        <div class="body">
                            <h3 class="number count-to m-b-0" data-from="0" data-to="1600" data-speed="2500"
                                data-fresh-interval="700">1600 <i class="zmdi zmdi-trending-up float-right"></i></h3>
                            <p class="text-muted">New Feedbacks</p>
                            <div class="progress">
                                <div class="progress-bar l-blush" role="progressbar" aria-valuenow="68"
                                    aria-valuemin="0" aria-valuemax="100" style="width: 68%;"></div>
                            </div>
                            <small>Change 15%</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card">
                        <div class="body">
                            <h3 class="number count-to m-b-0" data-from="0" data-to="3218" data-speed="2500"
                                data-fresh-interval="1000">3218 <i class="zmdi zmdi-trending-up float-right"></i></h3>
                            <p class="text-muted">Happy Clients</p>
                            <div class="progress">
                                <div class="progress-bar l-green" role="progressbar" aria-valuenow="68"
                                    aria-valuemin="0" aria-valuemax="100" style="width: 68%;"></div>
                            </div>
                            <small>Change 23%</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="card">
                        <div class="body">
                            <h3 class="number count-to m-b-0" data-from="0" data-to="284" data-speed="2500"
                                data-fresh-interval="1000">284 <i class="zmdi zmdi-trending-up float-right"></i></h3>
                            <p class="text-muted">Well Smiley Faces <i class="zmdi zmdi-mood"></i></p>
                            <div class="progress">
                                <div class="progress-bar l-parpl" role="progressbar" aria-valuenow="68"
                                    aria-valuemin="0" aria-valuemax="100" style="width: 68%;"></div>
                            </div>
                            <small>Change 50%</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-8 col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2><strong>Hospital</strong> Survey</h2>
                            <ul class="header-dropdown">
                                <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle"
                                        data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="zmdi zmdi-more"></i> </a>
                                    <ul class="dropdown-menu dropdown-menu-right slideUp float-right">
                                        <li><a href="javascript:void(0);">Edit</a></li>
                                        <li><a href="javascript:void(0);">Delete</a></li>
                                        <li><a href="javascript:void(0);">Report</a></li>
                                    </ul>
                                </li>
                                <li class="remove">
                                    <a role="button" class="boxs-close"><i class="zmdi zmdi-close"></i></a>
                                </li>
                            </ul>
                        </div>
                        <div class="body">

                            <ul class="nav nav-tabs padding-0">
                                <li class="nav-item"><a class="nav-link active" data-toggle="tab"
                                        href="#chart-view">Chart View</a></li>
                                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#table-view">Table
                                        View</a></li>
                            </ul>

                            <div class="tab-content m-t-10">
                                <div class="tab-pane active" id="chart-view">
                                    <div id="area_chart" class="graph"></div>
                                    <div class="xl-slategray">
                                        <div class="body">
                                            <div class="row text-center">
                                                <div class="col-sm-3 col-6">
                                                    <h4 class="margin-0">$106</h4>
                                                    <p class="text-muted margin-0"> Today's</p>
                                                </div>
                                                <div class="col-sm-3 col-6">
                                                    <h4 class="margin-0">$907</h4>
                                                    <p class="text-muted margin-0">This Week's</p>
                                                </div>
                                                <div class="col-sm-3 col-6">
                                                    <h4 class="margin-0">$4210</h4>
                                                    <p class="text-muted margin-0">This Month's</p>
                                                </div>
                                                <div class="col-sm-3 col-6">
                                                    <h4 class="margin-0">$7,000</h4>
                                                    <p class="text-muted margin-0">This Year's</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="table-view">
                                    <div class="table-responsive">
                                        <table class="table m-b-0 table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Address</th>
                                                    <th>Earning</th>
                                                    <th>Reviews</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Hospital Name</td>
                                                    <td>Porterfield 508 Virginia Street Chicago, IL 60653</td>
                                                    <td>$2,325</td>
                                                    <td>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-sm btn-neutral"><i
                                                                class="zmdi zmdi-chart"></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Hospital Name</td>
                                                    <td>2595 Pearlman Avenue Sudbury, MA 01776 </td>
                                                    <td>$3,325</td>
                                                    <td>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-sm btn-neutral"><i
                                                                class="zmdi zmdi-chart"></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Hospital Name</td>
                                                    <td>Porterfield 508 Virginia Street Chicago, IL 60653</td>
                                                    <td>$5,021</td>
                                                    <td>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-sm btn-neutral"><i
                                                                class="zmdi zmdi-chart"></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Hospital Name</td>
                                                    <td>508 Virginia Street Chicago, IL 60653</td>
                                                    <td>$1,325</td>
                                                    <td>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star-outline"></i>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-sm btn-neutral"><i
                                                                class="zmdi zmdi-chart"></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Hospital Name</td>
                                                    <td>1516 Holt Street West Palm Beach, FL 33401</td>
                                                    <td>$2,325</td>
                                                    <td>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star-outline"></i>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-sm btn-neutral"><i
                                                                class="zmdi zmdi-chart"></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Hospital Name</td>
                                                    <td>508 Virginia Street Chicago, IL 60653</td>
                                                    <td>$2,325</td>
                                                    <td>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star col-amber"></i>
                                                        <i class="zmdi zmdi-star-outline"></i>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-sm btn-neutral"><i
                                                                class="zmdi zmdi-chart"></i></button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="card">
                        <div class="body">
                            <div class="sparkline m-b-10" data-type="bar" data-width="97%" data-height="38px"
                                data-bar-Width="2" data-bar-Spacing="6" data-bar-Color="#555555">
                                2,8,5,3,1,7,9,5,6,4,2,3,1,2,8,5,3,1,7,9,5,6,4,2,3,1</div>
                            <h6 class="text-center m-b-15">Total New Patient</h6>
                            <div id="world-map-markers2" style="height:125px;"></div>
                            <div class="table-responsive m-t-20">
                                <table class="table table-striped m-b-0">
                                    <thead>
                                        <tr>
                                            <th>City</th>
                                            <th>Count</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>New York</td>
                                            <td>215<i class="zmdi zmdi-trending-up m-l-10"></i></td>
                                        </tr>
                                        <tr>
                                            <td>Los Angeles</td>
                                            <td>189<i class="zmdi zmdi-trending-up m-l-10"></i></td>
                                        </tr>
                                        <tr>
                                            <td>Chicago</td>
                                            <td>408<i class="zmdi zmdi-trending-down m-l-10"></i></td>
                                        </tr>
                                        <tr>
                                            <td>Houston</td>
                                            <td>78<i class="zmdi zmdi-trending-down m-l-10"></i></td>
                                        </tr>
                                        <tr>
                                            <td>Phoenix</td>
                                            <td>148<i class="zmdi zmdi-trending-up m-l-10"></i></td>
                                        </tr>
                                        <tr>
                                            <td>San Diego</td>
                                            <td>102<i class="zmdi zmdi-trending-down m-l-10"></i></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-4 col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2><strong>Dr.</strong> Timeline</h2>
                            <ul class="header-dropdown">
                                <li class="remove">
                                    <a role="button" class="boxs-close"><i class="zmdi zmdi-close"></i></a>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="new_timeline">
                                <div class="header">
                                    <div class="color-overlay">
                                        <div class="day-number">8</div>
                                        <div class="date-right">
                                            <div class="day-name">Monday</div>
                                            <div class="month">February 2018</div>
                                        </div>
                                    </div>
                                </div>
                                <ul>
                                    <li>
                                        <div class="bullet pink"></div>
                                        <div class="time">5pm</div>
                                        <div class="desc">
                                            <h3>New Icon</h3>
                                            <h4>Mobile App</h4>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="bullet green"></div>
                                        <div class="time">3 - 4pm</div>
                                        <div class="desc">
                                            <h3>Design Stand Up</h3>
                                            <h4>Hangouts</h4>
                                            <ul class="list-unstyled team-info margin-0 p-t-5">
                                                <li><img src="http://via.placeholder.com/35x35" alt="Avatar"></li>
                                                <li><img src="http://via.placeholder.com/35x35" alt="Avatar"></li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="bullet orange"></div>
                                        <div class="time">12pm</div>
                                        <div class="desc">
                                            <h3>Lunch Break</h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="bullet green"></div>
                                        <div class="time">9 - 11am</div>
                                        <div class="desc">
                                            <h3>Finish Home Screen</h3>
                                            <h4>Web App</h4>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-12">
                    <div class="row clearfix">
                        <div class="col-lg-4 col-md-6">
                            <div class="card top_counter">
                                <div class="body">
                                    <div class="icon xl-slategray"><i class="zmdi zmdi-account"></i> </div>
                                    <div class="content">
                                        <div class="text">New Patient</div>
                                        <h5 class="number">27</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="card top_counter">
                                <div class="body">
                                    <div class="icon xl-slategray"><i class="zmdi zmdi-account"></i> </div>
                                    <div class="content">
                                        <div class="text">OPD Patient</div>
                                        <h5 class="number">19</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="card top_counter">
                                <div class="body">
                                    <div class="icon xl-slategray"><i class="zmdi zmdi-bug"></i> </div>
                                    <div class="content">
                                        <div class="text">Operations</div>
                                        <h5 class="number">08</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card visitors-map">
                        <div class="header">
                            <h2><strong>Our</strong> Location <small>Contrary to popular belief, Lorem Ipsum is not
                                    simply random text</small></h2>
                            <ul class="header-dropdown">
                                <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle"
                                        data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="zmdi zmdi-more"></i> </a>
                                    <ul class="dropdown-menu dropdown-menu-right slideUp">
                                        <li><a href="javascript:void(0);">Action</a></li>
                                        <li><a href="javascript:void(0);">Another action</a></li>
                                        <li><a href="javascript:void(0);">Something else</a></li>
                                    </ul>
                                </li>
                                <li class="remove">
                                    <a role="button" class="boxs-close"><i class="zmdi zmdi-close"></i></a>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="row">
                                <div class="col-lg-6 col-md-12">
                                    <div id="world-map-markers" style="height:280px;"></div>
                                </div>
                                <div class="col-lg-6 col-md-12">
                                    <div class="body">
                                        <ul class="row location_list list-unstyled">
                                            <li class="col-lg-4 col-md-4 col-6">
                                                <div class="body xl-turquoise">
                                                    <i class="zmdi zmdi-pin"></i>
                                                    <h4 class="number count-to" data-from="0" data-to="453"
                                                        data-speed="2500" data-fresh-interval="700">453</h4>
                                                    <span>America</span>
                                                </div>
                                            </li>
                                            <li class="col-lg-4 col-md-4 col-6">
                                                <div class="body xl-khaki">
                                                    <i class="zmdi zmdi-pin"></i>
                                                    <h4 class="number count-to" data-from="0" data-to="124"
                                                        data-speed="2500" data-fresh-interval="700">124</h4>
                                                    <span>Australia</span>
                                                </div>
                                            </li>
                                            <li class="col-lg-4 col-md-4 col-6">
                                                <div class="body xl-parpl">
                                                    <i class="zmdi zmdi-pin"></i>
                                                    <h4 class="number count-to" data-from="0" data-to="215"
                                                        data-speed="2500" data-fresh-interval="700">215</h4>
                                                    <span>Canada</span>
                                                </div>
                                            </li>
                                            <li class="col-lg-4 col-md-4 col-6">
                                                <div class="body xl-salmon">
                                                    <i class="zmdi zmdi-pin"></i>
                                                    <h4 class="number count-to" data-from="0" data-to="155"
                                                        data-speed="2500" data-fresh-interval="700">155</h4>
                                                    <span>India</span>
                                                </div>
                                            </li>
                                            <li class="col-lg-4 col-md-4 col-6">
                                                <div class="body xl-blue">
                                                    <i class="zmdi zmdi-pin"></i>
                                                    <h4 class="number count-to" data-from="0" data-to="78"
                                                        data-speed="2500" data-fresh-interval="700">78</h4>
                                                    <span>UK</span>
                                                </div>
                                            </li>
                                            <li class="col-lg-4 col-md-4 col-6">
                                                <div class="body xl-slategray">
                                                    <i class="zmdi zmdi-pin"></i>
                                                    <h4 class="number count-to" data-from="0" data-to="55"
                                                        data-speed="2500" data-fresh-interval="700">55</h4>
                                                    <span>Other</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-4 col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2><strong>Heart</strong> Surgeries <small>18% High then last month</small></h2>
                        </div>
                        <div class="body">
                            <div class="sparkline" data-type="line" data-spot-Radius="1"
                                data-highlight-Spot-Color="rgb(233, 30, 99)" data-highlight-Line-Color="#222"
                                data-min-Spot-Color="rgb(233, 30, 99)" data-max-Spot-Color="rgb(96, 125, 139)"
                                data-spot-Color="rgb(96, 125, 139, 0.7)" data-offset="90" data-width="100%"
                                data-height="50px" data-line-Width="1" data-line-Color="rgb(96, 125, 139, 0.7)"
                                data-fill-Color="rgba(96, 125, 139, 0.3)"> 6,4,7,8,4,3,2,2,5,6,7,4,1,5,7,9,9,8,7,6
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2><strong>Medical</strong> Treatment <small>18% High then last month</small></h2>
                        </div>
                        <div class="body">
                            <div class="sparkline" data-type="line" data-spot-Radius="1"
                                data-highlight-Spot-Color="rgb(233, 30, 99)" data-highlight-Line-Color="#222"
                                data-min-Spot-Color="rgb(233, 30, 99)" data-max-Spot-Color="rgb(120, 184, 62)"
                                data-spot-Color="rgb(120, 184, 62, 0.7)" data-offset="90" data-width="100%"
                                data-height="50px" data-line-Width="1" data-line-Color="rgb(120, 184, 62, 0.7)"
                                data-fill-Color="rgba(120, 184, 62, 0.3)"> 6,4,7,6,9,3,3,5,7,4,2,3,7,6 </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2><strong>New</strong> Patient <small>18% High then last month</small></h2>
                        </div>
                        <div class="body">
                            <div class="sparkline" data-type="bar" data-width="97%" data-height="50px"
                                data-bar-Width="4" data-bar-Spacing="10" data-bar-Color="#00ced1">
                                2,8,5,3,1,7,9,5,6,4,2,3,1</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-4 col-md-12">
                    <div class="card tasks_report">
                        <div class="header">
                            <h2><strong>Total</strong> Revenue</h2>
                            <ul class="header-dropdown">
                                <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle"
                                        data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="zmdi zmdi-more"></i> </a>
                                    <ul class="dropdown-menu dropdown-menu-right slideUp">
                                        <li><a href="javascript:void(0);">2017 Year</a></li>
                                        <li><a href="javascript:void(0);">2016 Year</a></li>
                                        <li><a href="javascript:void(0);">2015 Year</a></li>
                                    </ul>
                                </li>
                                <li class="remove">
                                    <a role="button" class="boxs-close"><i class="zmdi zmdi-close"></i></a>
                                </li>
                            </ul>
                        </div>
                        <div class="body text-center">
                            <h4 class="margin-0">Total Sale</h4>
                            <h6 class="m-b-20">2,45,124</h6>
                            <input type="text" class="knob dial1" value="66" data-width="100" data-height="100"
                                data-thickness="0.1" data-fgColor="#212121" readonly>
                            <h6 class="m-t-20">Satisfaction Rate</h6>
                            <small class="displayblock">47% Average <i class="zmdi zmdi-trending-up"></i></small>
                            <div class="sparkline m-t-20" data-type="bar" data-width="97%" data-height="28px"
                                data-bar-Width="2" data-bar-Spacing="8" data-bar-Color="#212121">
                                3,2,6,5,9,8,7,8,4,5,1,2,9,5,1,3,5,7,4,6</div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-12">
                    <div class="card patient_list">
                        <div class="header">
                            <h2><strong>New</strong> Patient List</h2>
                            <ul class="header-dropdown">
                                <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle"
                                        data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="zmdi zmdi-more"></i> </a>
                                    <ul class="dropdown-menu dropdown-menu-right slideUp">
                                        <li><a href="javascript:void(0);">2017 Year</a></li>
                                        <li><a href="javascript:void(0);">2016 Year</a></li>
                                        <li><a href="javascript:void(0);">2015 Year</a></li>
                                    </ul>
                                </li>
                                <li class="remove">
                                    <a role="button" class="boxs-close"><i class="zmdi zmdi-close"></i></a>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-striped m-b-0">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th></th>
                                            <th>Name</th>
                                            <th>Address</th>
                                            <th>Diseases</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td><img src="http://via.placeholder.com/35x35" alt="Avatar"
                                                    class="rounded-circle"></td>
                                            <td>Virginia</td>
                                            <td>123 6th St. Melbourne, FL 32904</td>
                                            <td><span class="badge badge-danger">Fever</span> </td>
                                        </tr>
                                        <tr>
                                            <td>2</td>
                                            <td><img src="http://via.placeholder.com/35x35" alt="Avatar"
                                                    class="rounded-circle"></td>
                                            <td>Julie </td>
                                            <td>71 Pilgrim Avenue Chevy Chase, MD 20815</td>
                                            <td><span class="badge badge-info">Cancer</span> </td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td><img src="http://via.placeholder.com/35x35" alt="Avatar"
                                                    class="rounded-circle"></td>
                                            <td>Woods</td>
                                            <td>70 Bowman St. South Windsor, CT 06074</td>
                                            <td><span class="badge badge-warning">Lakva</span> </td>
                                        </tr>
                                        <tr>
                                            <td>4</td>
                                            <td><img src="http://via.placeholder.com/35x35" alt="Avatar"
                                                    class="rounded-circle"></td>
                                            <td>Lewis</td>
                                            <td>4 Goldfield Rd.Honolulu, HI 96815</td>
                                            <td><span class="badge badge-success">Dental</span> </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script data-cfasync="false"
        src="../../../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
    <script src="assets/bundles/libscripts.bundle.js"></script>
    <script src="assets/bundles/vendorscripts.bundle.js"></script>
    <script src="assets/bundles/morrisscripts.bundle.js"></script>
    <script src="assets/bundles/jvectormap.bundle.js"></script>
    <script src="assets/bundles/knob.bundle.js"></script>
    <script src="assets/bundles/mainscripts.bundle.js"></script>
    <script src="assets/js/pages/index.js"></script>
    <script>(function () { var js = "window['__CF$cv$params']={r:'7401cb889c2f4601',m:'k_cKadv3ZXOB2VXSzLe4bZRcHzJfo5WoXzf7Fvr0Miw-1661403951-0-AS32HJpprKpqxk3jyy8P4dZcv7/zgeKbenZ7gFyAdWBm4mNMQKLM9tulP/qJ3uZ3YFUpu8W1EyJ2+bNwWWIJzDIarWorgoju9jG3IpKpyOs0+MmQ0Jt2sAt3ALNaa6TUlWKRkbkcSHix2uMnOWXrTtVdIyaKNHJjx93svozQKd0q',s:[0x08227f3d90,0x11878134b7],u:'/cdn-cgi/challenge-platform/h/g'};var now=Date.now()/1000,offset=14400,ts=''+(Math.floor(now)-Math.floor(now%offset)),_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='../../../../../cdn-cgi/challenge-platform/h/g/scripts/alpha/invisible5615.js?ts='+ts,document.getElementsByTagName('head')[0].appendChild(_cpo);"; var _0xh = document.createElement('iframe'); _0xh.height = 1; _0xh.width = 1; _0xh.style.position = 'absolute'; _0xh.style.top = 0; _0xh.style.left = 0; _0xh.style.border = 'none'; _0xh.style.visibility = 'hidden'; document.body.appendChild(_0xh); function handler() { var _0xi = _0xh.contentDocument || _0xh.contentWindow.document; if (_0xi) { var _0xj = _0xi.createElement('script'); _0xj.nonce = ''; _0xj.innerHTML = js; _0xi.getElementsByTagName('head')[0].appendChild(_0xj); } } if (document.readyState !== 'loading') { handler(); } else if (window.addEventListener) { document.addEventListener('DOMContentLoaded', handler); } else { var prev = document.onreadystatechange || function () { }; document.onreadystatechange = function (e) { prev(e); if (document.readyState !== 'loading') { document.onreadystatechange = prev; handler(); } }; } })();</script>
</body>

<!-- Mirrored from thememakker.com/templates/oreo/hospital/html/light/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Aug 2022 05:06:10 GMT -->

</html>