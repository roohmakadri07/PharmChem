<?php

$host = 'localhost';
$dbname = 'pharmChem';
$user = 'root';
$pass = '';

$con = mysqli_connect($host,$user,$pass,$dbname);

if(!$con)
{
    die("Connection Failed.");
}

?>