<?php include 'innertop.php'; ?>


<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-5 col-sm-12">
                <h2>
                    Welcome to PharmChem
                </h2>
            </div>
            <div class="col-lg-5 col-md-7 col-sm-12">
                <button class="btn btn-white btn-icon btn-round d-none d-md-inline-block float-right m-l-10" type="button">
                    <i class="zmdi zmdi-plus"></i>
                </button>
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="index.html"><i class="zmdi zmdi-home"></i> Oreo</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Sample Pages</a></li>
                    <li class="breadcrumb-item active">Stater Page</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row clearfix">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>Patient's</strong> Prescription Information <small></small>
                        </h2>
                        <ul class="header-dropdown">
                            <li class="remove">
                                <a role="button" class="boxs-close"><i class="zmdi zmdi-close"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="body">
                        <div class="row clearfix">

                            <div class="col-sm-12">
                                <form method="POST">
                                    <div class="form-group">
                                        <input type="text" name="patient" class="form-control" placeholder="Patient's name">
                                    </div>
                            </div>

                            <div class="col-sm-12">
                                <button type="submit" class="btn btn-primary btn-round">Search</button>
                                <!-- <button type="submit" class="btn btn-default btn-round btn-simple">Cancel</button> -->
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-md-12">
                <div class="card patients-list">
                    <div class="header">
                        <h2><strong>Patients</strong> List</h2>
                        <ul class="header-dropdown">
                            <li class="remove">
                                <a role="button" class="boxs-close"><i class="zmdi zmdi-close"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="body">
                        <?php
                        if (isset($_POST['patient'])) {
                            $pname = $_POST['patient'];
                            $query = "SELECT * FROM user WHERE user_name='$pname'";
                            $result = mysqli_query($con, $query);

                        ?>


                            <div class="tab-content m-t-10">
                                <div class="tab-pane table-responsive active" id="All">
                                    <table class="table m-b-0 table-hover">
                                        <thead>
                                            <tr>
                                                <th>Media</th>
                                                <th>Patients ID</th>
                                                <th>Name</th>
                                                <th>Date</th>
                                                <th>View</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php
                                            while ($r = mysqli_fetch_array($result)) {
                                            ?>
                                                <tr>
                                                    <td><span class="list-icon"><img class="patients-img" src="profile-image-2.png" alt=""></span></td>
                                                    <td><span class="list-name"><?php echo $r['user_id']; ?></span></td>
                                                    <td><?php echo $r['user_name']; ?></td>
                                                    <td></td>

                                                    <td><a href="patientsymptoms.php?id=<?php echo $r['user_id']; ?>" class="btn btn-primary btn-round">View</a>
                                                    </td>
                                                </tr>
                                        <?php
                                            }
                                        }
                                        ?>

                                        </tbody>

                                    </table>
                                </div>

                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    </div>
</section>



<?php include 'innerbottom.php'; ?>