from django.shortcuts import render
from django.http import HttpResponse, JsonResponse

# Create your views here.

import argparse
import json
import os
from typing import Tuple, List
import base64 

import cv2
import editdistance
from path import Path

from src.dataloader_iam import DataLoaderIAM, Batch
from src.model import Model, DecoderType
from src.preprocessor import Preprocessor

import numpy as np
from matplotlib import pyplot as plt
import pandas as pd
import matplotlib as mpl
import traceback

class FilePaths:
    """Filenames and paths to data."""
    fn_char_list = '/Users/apple/Desktop/finalModel/src/line-model/charList.txt'
    fn_summary = '/Users/apple/Desktop/finalModel/src/line-model/summary.json'
    fn_corpus = '/Users/apple/Desktop/finalModel/src/data/corpus.txt'

def decodeImg(image_file):
	image = image_file

	img_code = base64.b64decode(image)

	cntr=1

	file_name = '/Users/apple/Desktop/finalModel/src/data/incoming_imgs/' + str(cntr) + '.jpg'
	cntr+=1
	with open(file_name,'wb') as f:
		f.write(img_code)

	return file_name

def splitImg(file_name):
	img = cv2.imread(file_name)
	gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	print("1")

	th, threshed = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV|cv2.THRESH_OTSU)
	hist = cv2.reduce(threshed,1, cv2.REDUCE_AVG).reshape(-1)
	th = 2
	H,W = img.shape[:2]
	uppers = [y for y in range(H-1) if hist[y]<=th and hist[y+1]>th]
	lowers = [y for y in range(H-1) if hist[y]>th and hist[y+1]<=th]

	dir = '/Users/apple/Desktop/finalModel/src/data/split_result'

	img_num = 1

	for i in range(len(uppers)):
		cv2.imwrite('/Users/apple/Desktop/finalModel/src/data/split_result/' + str(img_num) + '.jpg', img[uppers[i]:lowers[i],:])
		img_num += 1  

def get_img_height() -> int:
    """Fixed height for NN."""
    return 32

def get_img_size(line_mode: bool = False) -> Tuple[int, int]:
    """Height is fixed for NN, width is set according to training mode (single words or text lines)."""
    if line_mode:
        return 256, get_img_height()
    return 128, get_img_height()

def write_summary(char_error_rates: List[float], word_accuracies: List[float]) -> None:
    """Writes training summary file for NN."""
    with open(FilePaths.fn_summary, 'w') as f:
        json.dump({'charErrorRates': char_error_rates, 'wordAccuracies': word_accuracies}, f)

def char_list_from_file() -> List[str]:
    with open(FilePaths.fn_char_list) as f:
        return list(f.read())

def train(model: Model,
          loader: DataLoaderIAM,
          line_mode: bool,
          early_stopping: int = 25) -> None:
    """Trains NN."""
    epoch = 0  # number of training epochs since start
    summary_char_error_rates = []
    summary_word_accuracies = []
    preprocessor = Preprocessor(get_img_size(line_mode), data_augmentation=True, line_mode=line_mode)
    best_char_error_rate = float('inf')  # best validation character error rate
    no_improvement_since = 0  # number of epochs no improvement of character error rate occurred
    # stop training after this number of epochs without improvement
    while True:
        epoch += 1
        print('Epoch:', epoch)

        # train
        print('Train NN')
        loader.train_set()
        while loader.has_next():
            iter_info = loader.get_iterator_info()
            batch = loader.get_next()
            batch = preprocessor.process_batch(batch)
            loss = model.train_batch(batch)
            print(f'Epoch: {epoch} Batch: {iter_info[0]}/{iter_info[1]} Loss: {loss}')

        # validate
        char_error_rate, word_accuracy = validate(model, loader, line_mode)

        # write summary
        summary_char_error_rates.append(char_error_rate)
        summary_word_accuracies.append(word_accuracy)
        write_summary(summary_char_error_rates, summary_word_accuracies)

        # if best validation accuracy so far, save model parameters
        if char_error_rate < best_char_error_rate:
            print('Character error rate improved, save model')
            best_char_error_rate = char_error_rate
            no_improvement_since = 0
            model.save()
        else:
            print(f'Character error rate not improved, best so far: {char_error_rate * 100.0}%')
            no_improvement_since += 1

        # stop training if no more improvement in the last x epochs
        if no_improvement_since >= early_stopping:
            print(f'No more improvement since {early_stopping} epochs. Training stopped.')
            break


def validate(model: Model, loader: DataLoaderIAM, line_mode: bool) -> Tuple[float, float]:
    """Validates NN."""
    print('Validate NN')
    loader.validation_set()
    preprocessor = Preprocessor(get_img_size(line_mode), line_mode=line_mode)
    num_char_err = 0
    num_char_total = 0
    num_word_ok = 0
    num_word_total = 0
    while loader.has_next():
        iter_info = loader.get_iterator_info()
        print(f'Batch: {iter_info[0]} / {iter_info[1]}')
        batch = loader.get_next()
        batch = preprocessor.process_batch(batch)
        recognized, _ = model.infer_batch(batch)

        print('Ground truth -> Recognized')
        for i in range(len(recognized)):
            num_word_ok += 1 if batch.gt_texts[i] == recognized[i] else 0
            num_word_total += 1
            dist = editdistance.eval(recognized[i], batch.gt_texts[i])
            num_char_err += dist
            num_char_total += len(batch.gt_texts[i])
            print('[OK]' if dist == 0 else '[ERR:%d]' % dist, '"' + batch.gt_texts[i] + '"', '->',
                  '"' + recognized[i] + '"')

    # print validation result
    char_error_rate = num_char_err / num_char_total
    word_accuracy = num_word_ok / num_word_total
    print(f'Character error rate: {char_error_rate * 100.0}%. Word accuracy: {word_accuracy * 100.0}%.')
    return char_error_rate, word_accuracy


def infer(model: Model, fn_img: Path) -> None:
    """Recognizes text in image provided by file path."""
    img = cv2.imread(fn_img, cv2.IMREAD_GRAYSCALE)
    assert img is not None

    preprocessor = Preprocessor(get_img_size(), dynamic_width=True, padding=16)
    img = preprocessor.process_img(img)

    batch = Batch([img], None, 1)
    recognized, probability = model.infer_batch(batch, True)
    # print(f'Recognized: "{recognized[0]}"')
    # print(f'Probability: {probability[0]}')

    lstInferred = []

    lstInferred.append(recognized)
    lstInferred.append(probability)

    return(lstInferred)

# def splitImg(file_name):
	# img = cv2.imread(file_name)
	# gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

	# th, threshed = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV|cv2.THRESH_OTSU)
	# hist = cv2.reduce(threshed,1, cv2.REDUCE_AVG).reshape(-1)

	# th = 2
	# H,W = img.shape[:2]
	# uppers = [y for y in range(H-1) if hist[y]<=th and hist[y+1]>th]
	# lowers = [y for y in range(H-1) if hist[y]>th and hist[y+1]<=th]

	# img_num = 1
	# for i in range(len(uppers)):
	# 	print(i)
	# 	cv2.imwrite('/Users/apple/Desktop/pharmchemOCR/ocr/result_split/' + str(img_num) + '.jpg', img[uppers[i]:lowers[i],:])
	# 	img_num += 1  

def main(request):
    """Main function."""

    img_file = request.POST['image']
    img = decodeImg(img_file)

    # segmentation(img)
    # splitLst = os.listdir('/Users/apple/Desktop/finalModel/src/data/split_result')

    lstResult = []
    # strRes = ""

    decoder_mapping = {'bestpath': DecoderType.BestPath,
                    'beamsearch': DecoderType.BeamSearch,
                    'wordbeamsearch': DecoderType.WordBeamSearch}

    decoder_type = decoder_mapping['bestpath']

    # model = Model(char_list_from_file(), decoder_type, must_restore=True, dump='store_true')
    # lstInferred = infer(model, img)

    # lstResult.append(lstInferred[0])

    # for f in splitLst:
    #     decoder_mapping = {'bestpath': DecoderType.BestPath,
    #                     'beamsearch': DecoderType.BeamSearch,
    #                     'wordbeamsearch': DecoderType.WordBeamSearch}

    #     decoder_type = decoder_mapping['bestpath']

    #     model = Model(char_list_from_file(), decoder_type, must_restore=True, dump='store_true')
    #     lstInferred = infer(model, f)

    #     lstResult.append(lstInferred[0])

    # for cntr in lstResult:
    #     strRes = strRes + cntr + "\n"

    # resultLst = {'text':strRes}
    # return JsonResponse(resultLst)


    # for i in splitLst:
    #     model = Model(char_list_from_file(), decoder_type, must_restore=True, dump=args.dump)
    #     lstInferred = infer(model, i)

    #     lstResult.append(lstInferred[0])

    #     print(lstInferred[0])
    #     print(lstInferred[1])

    # return HttpResponse(lstInferred[0])

    model = Model(char_list_from_file(), decoder_type, must_restore=True, dump='store_true')
    lstInferred = infer(model, img)

    resultLst = {'text':lstInferred[0]}

    return JsonResponse(resultLst)

def segmentation(img):

    img2 = cv2.imread(img)
    gray = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    th, threshed = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV|cv2.THRESH_OTSU)
   
    upper=[]
    lower=[]
    flag=True
    for i in range(threshed.shape[0]):

        col = threshed[i:i+1,:]
        cnt=0
        if flag:
            cnt=np.count_nonzero(col == 255)
            if cnt>0:
                upper.append(i)
                flag=False
        else:
            cnt=np.count_nonzero(col == 255)
            if cnt<2:
                lower.append(i)
                flag=True

    textLines=[]
    if len(upper)!= len(lower):lower.append(threshed.shape[0])
#    print upper
#    print lower
    for i in range(len(upper)):
        timg=img2[upper[i]:lower[i],0:]
        if timg.shape[0]>5:
#            plt.imshow(timg)
#            plt.show()
            timg=cv2.resize(timg,((timg.shape[1]*5,timg.shape[0]*8)))
            textLines.append(timg)

            cntr=1

            file_name = '/Users/apple/Desktop/finalModel/src/data/split_result/' + str(cntr) + '.jpg'
            cntr+=1
            with open(file_name,'wb') as f:
                f.write(timg)