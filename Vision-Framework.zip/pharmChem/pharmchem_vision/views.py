from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse, JsonResponse
import os,io
import uuid
import base64
from google.cloud import vision_v1
from google.cloud.vision_v1 import types
import pandas as pd

def getImage(request):

	image_data = request.POST['image']
	print(image_data)
	data = base64.b64decode(image_data)

	file_name = str(uuid.uuid4())	
	print(file_name)
	file_path = '/Users/apple/Desktop/pharmChem/pharmchem_vision/images/' + file_name + '.jpg'

	with open(file_path,'wb') as f:
		print("hello")
		f.write(data)

	text = visionAPI(file_name)
	dictData={"text":text}

	#print(text)
	return JsonResponse(dictData)

def visionAPI(file_name):
	os.environ['GOOGLE_APPLICATION_CREDENTIALS']=r'/Users/apple/Desktop/pharmChem/pharmchem_vision/ocrtext-360405-e6b0b4b25b78.json'
	client=vision_v1.ImageAnnotatorClient()

	FOLDER_PATH="/Users/apple/Desktop/pharmChem/pharmchem_vision/images"
	IMAGE_FILE=file_name + '.jpg'
	FILE_PATH=os.path.join(FOLDER_PATH,IMAGE_FILE)

	with io.open(FILE_PATH,'rb')as image_file:
		print("in read")
		content=image_file.read()

	image=vision_v1.types.Image(content=content)
	response=client.document_text_detection(image=image)
	docText=response.full_text_annotation.text

	print(docText)
	return(docText)

	print("a")

